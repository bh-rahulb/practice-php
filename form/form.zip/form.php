<?php

$fname=$_POST['f_name'];
$lname=$_POST['l_name'];
$email=$_POST['email'];
$password=$_POST['password'];
$c_password=$_POST['c_password'];
$city=$_POST['city'];
$state=$_POST['state'];
$gender=$_POST['gender'];
$hobbies=$_POST['hobbies'];

foreach ($hobbies as $hobbs) {
   $hobby .= $hobbs . " ";
}


echo "<pre>";
echo "<h3>First Name:         $fname</h3>";
echo "<h3>Last Name:          $lname</h3>";
echo "<h3>email:              $email</h3>";
echo "<h3>password :          $password</h3>";
echo "<h3>Confirm Password :  $c_password</h3>";
echo "<h3>City:               $city</h3>";
echo "<h3>State:              $state</h3>";
echo "<h3>Gender:             $gender</h3>";
echo "<h3>Hobbies:            $hobby</h3>";
echo "</pre>";



?>