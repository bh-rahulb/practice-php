<?php
session_start();
if(isset($_SESSION['lname'])){

}else{
    header('location:lname.php');
    exit();
}
print_r ($_SESSION);
include("head.html");

$email_err="";

if($_SERVER['REQUEST_METHOD']== 'POST'){
    
    $email=htmlspecialchars($_POST['email']);

    if (empty($email)){
        $email_err="email is required";
    }else{
        $email=trim($email);
    }

}

?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="rounded border p-3">
    <div class="d-flex pb-2">
        <label class="w-35" for="email">Email <span class="text-danger">*</span> :</label>
        <div class="flex-fill w-50">
            <input class="form-control" type="text" name="email" id="email" value="<?php echo isset($_SESSION['email']) ? $_SESSION['email'] : ''?>"/>
            <div class="text-danger ps-2">
                <?php echo $email_err; ?>
            </div>
        </div>
    </div>
    <div class="d-flex align-items-center pt-3 text-center">
        <div class="w-50">
            <button class="btn btn-success w-50" type="submit">Submit</button>
        </div>
        <div class="w-50">
            <a class="btn btn-success w-50" href="lname.php">Back</a>
        </div>
    </div>
</form>


<?php

include("foot.html");

// unset($_SESSION['email']);
if($_SERVER['REQUEST_METHOD']== 'POST'){
    if(empty($email_err)){
        $_SESSION['email']=$email;
        header("location:password.php");
    }
}


?>