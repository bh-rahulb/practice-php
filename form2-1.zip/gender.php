<?php
session_start();
if(isset($_SESSION['state'])){

}else{
    header('location:state.php');
    exit();
}
print_r ($_SESSION);
include("head.html");

$gender_err="";
$gender="";

if($_SERVER['REQUEST_METHOD']== 'POST'){
    
    $gender=$_POST['gender'];

    if (empty($gender)){
        $gender_err="gender is required";
    }


}

?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="rounded border p-3">
    <div class="d-flex py-2">
        <label class="w-35" for="gender">Gender <span class="text-danger">*</span> :</label>
        <div class="flex-fill w-50">
            <div>
                <label class="pe-2" for="male">
                    Male <input class="mx-2" type="radio" name="gender" value="Male" id="male" <?php echo (isset($_SESSION['gender'])&&($_SESSION['gender']=='Male')) ? 'checked' : '' ?> />
                </label>
                <label class="ms-1 pe-2" for="female">
                    Female <input class="mx-2" type="radio" name="gender" value="female" id="female" <?php echo (isset($_SESSION['gender'])&&($_SESSION['gender']=='Female')) ? 'checked' : '' ?> />
                </label>
            </div>
        <div class="w-100 text-danger ps-2">
            <?php echo $gender_err; ?>
        </div>
        </div>
    </div>
    <div class="d-flex align-items-center pt-3 text-center">
        <div class="w-50">
            <button class="btn btn-success w-50" type="submit">Submit</button>
        </div>
        <div class="w-50">
            <a class="btn btn-success w-50" href="state.php">Back</a>
        </div>
    </div>
</form>

<?php

include("foot.html");

// unset($_SESSION['gender']);
if($_SERVER['REQUEST_METHOD']== 'POST'){
    if(empty($gender_err)){
        $_SESSION['gender']=$gender;
        header("location:hobbies.php");
    }
}


?>