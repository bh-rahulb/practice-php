<?php
function create_thumb($image,$name,$width,$height){
    
if (is_file($image)){
    // get image size
    $info= getimagesize($image);
    // var_dump ($info);

    $img_width=$info[0];
    $img_height=$info[1];
    $img_type=$info['mime'];

    // check image format
    if($img_type=="image/jpeg"){
        $source=imagecreatefromjpeg($image);
    }elseif($img_type=="image/png"){
        $source=imagecreatefrompng($image);
    }elseif($img_type=="image/gif"){
        $source=imagecreatefromgif($image);
    }
    else{
        return false;
    }

}else{
    echo 'file not exists';
}

// create black image
$thumb=imagecreatetruecolor($width,$height);

// copy uploaded image and insert in black image created as thumb acording to cordinates
$resize=imagecopyresized($thumb,$source,0,0,0,0,$width,$height,$img_width,$img_height);

if ($resize){
    $target="images/thumbnail_".$width."x".$height."_".$name;
    imagepng($thumb,$target);
}else{
    echo "copy error";
}

// echo "process done";
}

// create_thumb("images/1702538632.jpg","new1.png", 300, 300);


?>

