<?php
session_start();
if(isset($_SESSION['image'])){

}else{
    header('location:image.php');
    exit();
}
print_r ($_SESSION);
include("head.html");

$message_err="";

if($_SERVER['REQUEST_METHOD']== 'POST'){
    
    $message=htmlspecialchars($_POST['message']);

    if (empty($message)){
        $message_err="message is required";
    }else{
        $message=trim($message);
    }


}

?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="rounded border p-3">
    <div class="d-flex py-2">
        <label class="w-35" for="message">Message <span class="text-danger">*</span> :</label>
        <div class="flex-fill w-50">
            <textarea class="form-control" name="message" id="message" rows="4"><?php echo isset($_SESSION['message']) ? $_SESSION['message'] : ''?></textarea>
            <div class="text-danger ps-2">
                <?php echo $message_err; ?>
            </div>
        </div>
     </div>
     <div class="d-flex align-items-center pt-3 text-center">
        <div class="w-50">
            <button class="btn btn-success w-50" type="submit">Submit</button>
        </div>
        <div class="w-50">
            <a class="btn btn-success w-50" href="image.php">Back</a>
        </div>
    </div>
</form>


<?php

include("foot.html");

// unset($_SESSION['message']);
if($_SERVER['REQUEST_METHOD']== 'POST'){
    if(empty($message_err)){
        $_SESSION['message']=$message;
        $_SESSION['a']=rand(1,25);;
        $_SESSION['b']=rand(0,12);

        header("location:captcha.php");
    }
}


?>