<?php
session_start();
if(isset($_SESSION['city'])){

}else{
    header('location:city.php');
    exit();
}
print_r ($_SESSION);
include("head.html");

$state_err="";

if($_SERVER['REQUEST_METHOD']== 'POST'){
    
    $state=$_POST['state'];

    if (empty($state)){
        $state_err="state is required";
    }


}
?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="rounded border p-3">
    <div class="d-flex py-2">
        <label class="w-35" for="state">State <span class="text-danger">*</span> :</label>
        <div class="flex-fill w-50">
            <select class="form-control" name="state" id="state">
                form.php <option value="">--select--</option>
                <option value="Punjab" <?php echo ($_SESSION['state']=='Punjab' ) ? 'selected' : '' ?> >Punjab</option>
                <option value="Haryana" <?php echo ($_SESSION['state']=='Haryana' ) ? 'selected' : '' ?> >Haryana</option>
                <option value="Himachal Pradesh" <?php echo ($_SESSION['state']=='Himachal Pradesh' ) ? 'selected' : '' ?> >Himachal Pradesh</option>
            </select>
            <div class="text-danger ps-2">
                <?php echo $state_err; ?>
            </div>
        </div>
    </div>
    <div class="d-flex align-items-center pt-3 text-center">
        <div class="w-50">
            <button class="btn btn-success w-50" type="submit">Submit</button>
        </div>
        <div class="w-50">
            <a class="btn btn-success w-50" href="city.php">Back</a>
        </div>
    </div>
</form>


<?php

include("foot.html");

// unset($_SESSION['state']);
if($_SERVER['REQUEST_METHOD']== 'POST'){
    if(empty($state_err)){
        $_SESSION['state']=$state;
        header("location:gender.php");

    }
}


?>