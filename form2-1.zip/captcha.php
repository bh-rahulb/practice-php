<?php
session_start();
if(isset($_SESSION['message'])){

}else{
    header('location:message.php');
    exit();
}
print_r ($_SESSION);
include("head.html");

$message_err="";

$a=$_SESSION['a'];
$b=$_SESSION['b'];
// $a=rand(1,24);
// $b=rand(0,13);


if($_SERVER['REQUEST_METHOD']== 'POST'){
    
    $sum=$a + $b;
    $captcha=htmlspecialchars($_POST['captcha']);
    if(empty($captcha)){
        $captcha_err="enter captcha";
    }elseif ($sum==$captcha) {
        $captcha_err="";
    }else{
        $captcha_err="incorrect";
    }

}

?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="rounded border p-3">
    <div class="d-flex py-2">
        <label class="w-35" for="captcha">Enter captcha  <span class="text-danger">*</span> : </label>
        <div class="flex-fill w-50">
            <?php echo $a. " + ".$b ." ="; ?>
            <input class="w-25 form-control" type="text" name="captcha" id="captcha">
            <div class="text-danger ps-2">
                <?php echo $captcha_err; ?>
            </div>
        </div>
    </div>
    <div class="d-flex align-items-center pt-3 text-center">
        <div class="w-50">
            <button class="btn btn-success w-50" type="submit">Submit</button>
        </div>
        <div class="w-50">
            <a class="btn btn-success w-50" href="message.php">Back</a>
        </div>
    </div>
</form>


<?php

// echo "<pre class='mt-4'>";
// echo isset($_SESSION['fname']) ?      "<p>First Name:          ". $_SESSION['fname'] : ''. "</p>";
// echo isset($_SESSION['lname']) ?      "<p>Last Name:           ". $_SESSION['lname'] : ''. "</p>";
// echo isset($_SESSION['email']) ?      "<p>Email:               ". $_SESSION['email'] : ''. "</p>";
// echo isset($_SESSION['password']) ?   "<p>Password:            ". $_SESSION['password'] : ''. "</p>";
// echo isset($_SESSION['c_password']) ? "<p>Confirm Password:    ". $_SESSION['c_password'] : ''. "</p>";
// echo isset($_SESSION['city']) ?       "<p>City:                ". $_SESSION['city'] : ''. "</p>";
// echo isset($_SESSION['state']) ?      "<p>State:               ". $_SESSION['state'] : ''. "</p>";
// echo isset($_SESSION['gender']) ?     "<p>Gender:              ". $_SESSION['gender'] : ''. "</p>";
// echo isset($_SESSION['hobbies']) ?    "<p>Hobbies:             ". $_SESSION['hobbies'] : ''. "</p>";
// echo isset($_SESSION['saved_name']) ? "<p>Image:               ". $_SESSION['saved_name'] : ''. "</p>";
// echo isset($_SESSION['message']) ?    "<p>message:             ". $_SESSION['message'] : ''. "</p>";
// // echo "<h5>message:            <p style='width:200px; padding:2px 10px; '>$message</p> </h3>";
// echo "</pre>";

// if (isset($_SESSION['saved_name'])){
//     $target_dir="images/".$_SESSION['saved_name'];
//     echo "<h4>Uploaded image</h4>";
//     echo "<div style='width:80%;margin:10px auto'>";
//     echo "<a href='$target_dir'><img src='$target_dir' style='width:100%;border-radius:4px' alt='$saved_name'/>";
//     echo "<p>$saved_name</p></a>";
//     echo "</div>";
// }

include("foot.html");

if($_SERVER['REQUEST_METHOD']== 'POST'){
    if(empty($captcha_err)){
        header("location:data.php");
    }
}


?>