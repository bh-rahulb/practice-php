<?php
session_start();
if(isset($_SESSION['password'])){

}else{
    header('location:password.php');
    exit();
}
print_r ($_SESSION);
include("head.html");

$c_password_err="";

if($_SERVER['REQUEST_METHOD']== 'POST'){
    
    $c_password=htmlspecialchars($_POST['c_password']);

    if (empty($c_password)){
        $c_password_err="please confirm password";
    }else{
        $c_password=trim($c_password);
    }


}

?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="rounded border p-3">
    <div class="d-flex pb-2">
        <label class="w-35" for="c_password">Confirm Password <span class="text-danger">*</span> :</label>
        <div class="flex-fill w-50">
            <input class="form-control" type="password" name="c_password" id="c_password" value="<?php echo isset($_SESSION['c_password']) ? $_SESSION['c_password'] : ''?>"/>
            <div class="text-danger ps-2">
                <?php echo $c_password_err; ?>
            </div>
        </div>
    </div>
    <div class="d-flex align-items-center pt-3 text-center">
        <div class="w-50">
            <button class="btn btn-success w-50" type="submit">Submit</button>
        </div>
        <div class="w-50">
            <a class="btn btn-success w-50" href="password.php">Back</a>
        </div>
    </div>
</form>


<?php

include("foot.html");

// unset($_SESSION['c_password']);
if($_SERVER['REQUEST_METHOD']== 'POST'){
    if(empty($c_password_err)){
        $_SESSION['c_password']=$c_password;
        header("location:city.php");

    }
}


?>