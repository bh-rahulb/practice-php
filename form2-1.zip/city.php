<?php
session_start();
if(isset($_SESSION['c_password'])){

}else{
    header('location:c_password.php');
    exit();
}
print_r ($_SESSION);
include("head.html");

$city_err="";

if($_SERVER['REQUEST_METHOD']== 'POST'){
    
    $city=$_POST['city'];

    if (empty($city)){
        $city_err="city is required";
    }

}

?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="rounded border p-3">
    <div class="d-flex py-2">
        <label class="w-35" for="city">City <span class="text-danger">*</span> :</label>
        <div class="flex-fill w-50">
            <select class="form-control" name="city" id="city">
                <option value="">--select--</option>
                <option value="Mohali" <?php echo ($_SESSION['city']=='Mohali' ) ? 'selected' : '' ?> >Mohali</option>
                <option value="Chandigarh" <?php echo ($_SESSION['city']=='Chandigarh' ) ? 'selected' : '' ?> >Chandigarh</option>
                <option value="Shimla" <?php echo ($_SESSION['city']=='Shimla' ) ? 'selected' : '' ?> >Shimla</option>
                <option value="Hamirpur" <?php echo ($_SESSION['city']=='Hamirpur' ) ? 'selected' : '' ?> >Hamirpur</option>
            </select>
            <div class="text-danger ps-2">
                <?php echo $city_err; ?>
            </div>
        </div>
    </div>
    <div class="d-flex align-items-center pt-3 text-center">
        <div class="w-50">
            <button class="btn btn-success w-50" type="submit">Submit</button>
        </div>
        <div class="w-50">
            <a class="btn btn-success w-50" href="c_password.php">Back</a>
        </div>
    </div>
</form>


<?php

include("foot.html");

// unset($_SESSION['city']);
if($_SERVER['REQUEST_METHOD']== 'POST'){
    if(empty($city_err)){
        $_SESSION['city']=$city;
        header("location:state.php");

    }
}


?>