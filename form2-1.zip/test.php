<?php

$dir=opendir('../');
while(false !==($file=readdir($dir))){
    $files[]=$file;
}
sort($files);
print_r ($files). \n;

closedir($dir);

?>