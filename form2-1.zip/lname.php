<?php
session_start();
if(isset($_SESSION['fname'])){

}else{
    header('location:fname.php');
    exit();
}
print_r ($_SESSION);
include("head.html");

$lname_err="";

if($_SERVER['REQUEST_METHOD']== 'POST'){
    
    $lname=htmlspecialchars($_POST['l_name']);

    if (empty($lname)){
        $lname_err="last name is required";
    }else{
        $lname=trim($lname);
    }


}

?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="rounded border p-3">
    <div class="d-flex pb-2">
        <label class="w-35" for="l_name">Last Name <span class="text-danger">*</span> :</label>
        <div class="flex-fill w-50">
            <input class="form-control" type="text" name="l_name" id="l_name" value="<?php echo isset($_SESSION['lname']) ? $_SESSION['lname'] : ''?>"/>
            <div class="text-danger ps-2">
                <?php echo $lname_err; ?>
            </div>
        </div>
    </div>
    <div class="d-flex align-items-center pt-3 text-center">
        <div class="w-50">
            <button class="btn btn-success w-50" type="submit">Submit</button>
        </div>
        <div class="w-50">
            <a class="btn btn-success w-50" href="fname.php">Back</a>
        </div>
    </div>
</form>


<?php

include("foot.html");

// unset($_SESSION['lname']);
if($_SERVER['REQUEST_METHOD']== 'POST'){
    if(empty($lname_err)){
        $_SESSION['lname']=$lname;
        header("location:email.php");
    }
}


?>