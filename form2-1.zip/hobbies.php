<?php
session_start();
if(isset($_SESSION['gender'])){

}else{
    header('location:c_password.php');
    exit();
}
print_r ($_SESSION);
include("head.html");

$hobbies_err="";
$hobbies=null;

if($_SERVER['REQUEST_METHOD']== 'POST'){
    
    $hobbies=$_POST['hobbies'];

    if (empty($hobbies)){
        $hobbies_err="hobby is required";
    }else{
        $hobby="";
        foreach ($hobbies as $hobbs) {
            $hobby .= $hobbs . " ";
        }
    }

}

?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" class="rounded border p-3">
    <div class="d-flex py-2">
        <label class="w-35" for="gender">Hobbies <span class="text-danger">*</span> :</label>
        <div class="flex-fill w-50">
            <div>
                <label class="pe-2" for="coding">
                    Coding <input class="mx-2" type="checkbox" name="hobbies[]" value="Coding" id="coding" <?php echo (stristr($_SESSION['hobbies'], "Coding" ))? "checked" : "" ; ?> />
                </label>
                <label class="ms-1 pe-2" for="gaming">
                    Gaming <input class="mx-2" type="checkbox" name="hobbies[]" value="Gaming" id="gaming" <?php echo (stristr($_SESSION['hobbies'], "Gaming" ))? "checked" : "" ; ?> />
                </label>
            </div>
            <div>
                <label class="pe-2" for="dancing">
                    Dancing <input class="mx-2" type="checkbox" name="hobbies[]" value="Dancing" id="dancing" <?php echo (stristr($_SESSION['hobbies'], "Dancing" ))? "checked" : "" ; ?> />
                </label>
                <label class="ms-1 pe-2" for="singing">
                    Singing <input class="mx-2" type="checkbox" name="hobbies[]" value="Singing" id="singing" <?php echo (stristr($_SESSION['hobbies'], "Singing" ))? "checked" : "" ; ?> />
                </label>
            </div>
            <div class="text-danger ps-2">
                <?php echo $hobbies_err; ?>
            </div>
        </div>
    </div>
    <div class="d-flex align-items-center pt-3 text-center">
        <div class="w-50">
            <button class="btn btn-success w-50" type="submit">Submit</button>
        </div>
        <div class="w-50">
            <a class="btn btn-success w-50" href="gender.php">Back</a>
        </div>
    </div>
</form>


<?php

include("foot.html");

// unset($_SESSION['hobbies']);
if($_SERVER['REQUEST_METHOD']== 'POST'){
    if(empty($hobbies_err)){
        $_SESSION['hobbies']=trim($hobby);
        header("location:image.php");
    }
}


?>